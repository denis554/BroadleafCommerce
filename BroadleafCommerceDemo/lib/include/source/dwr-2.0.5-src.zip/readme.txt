
Tags used in source tree
------------------------

PERFORMANCE:
  This code is not optimal, however we are delaying tweaking until we know that
  performance is an issue
TODO:
  Something needs completing
JDK*:
  When we move the default support level from one JDK to another, we will need
  to alter this code
